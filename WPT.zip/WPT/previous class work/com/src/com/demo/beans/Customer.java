package com.demo.beans;


public class Customer extends person
{
    private String type;
    private double limit;
	public Customer() 
	{
		super();
	}
	public Customer(int id, String name, String mob,String type, double limit) {
		super(id,name,mob);
		this.type = type;
		this.limit = limit;
	}
	public String getType() 
	{
		return type;
	}
	public void setType(String type)
	{
		this.type = type;
	}
	public double getLimit() 
	{
		return limit;
	}
	public void setLimit(double limit) 
	{
		this.limit = limit;
	}
	@Override
	public String toString() {
		return super.toString() + "Customer [type=" + type + ", limit=" + limit + "]";
	}
	
	
	
}
