package com.demo.beans;

public abstract class employee extends person
{
	private String dept;	
	private String desgn;
	public employee() 
	{
		System.out.println("in employee default constructor");
	}
	public employee(int id, String name, String mob,String dept, String desgn)
	{
		super(id,name,mob);
		this.dept = dept;
		this.desgn = desgn;
	}
	public String getDept()
	{
		return dept;
	}
	public void setDept(String dept) 
	{
		this.dept = dept;
	}
	public String getDesgn()
	{
		return desgn;
	}
	public void setDesgn(String desgn) 
	{
		this.desgn = desgn;
	}
	
	public abstract double calsal();
	@Override
	public String toString() {
		return super.toString() + "employee [dept=" + dept + ", desgn=" + desgn + "]";
	}
	

}
