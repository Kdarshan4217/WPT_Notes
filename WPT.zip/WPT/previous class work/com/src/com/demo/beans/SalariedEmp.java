package com.demo.beans;

public class SalariedEmp extends employee
{
	
	private double sal;
	private double bonus;
	public SalariedEmp(int id, String name, String mob,String dept, String desgn,double sal, double bonus) 
	{
		super(id,name,mob,dept,desgn);
		this.sal = sal;
		this.bonus = bonus;
	}
	public SalariedEmp() 
	{
		super();
	}
	public double getSal() 
	{
		return sal;
	}
	public void setSal(double sal)
	{
		this.sal = sal;
	}
	public double getBonus() 
	{
		return bonus;
	}
	public void setBonus(double bonus) 
	{
		this.bonus = bonus;
	}
	
	@Override
	public double calsal()
	{
		return sal+bonus+0.10*sal+0.15*sal-0.08*sal ;
	}
	@Override
	public String toString() 
	{
		return super.toString()+"SalariedEmp [sal=" + sal + ", bonus=" + bonus + "]";
	}
	
}
