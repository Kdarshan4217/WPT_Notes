package com.demo.test;

import com.demo.beans.person;
import com.demo.beans.employee;
import com.demo.beans.SalariedEmp;
import com.demo.beans.ContractEmp;
import com.demo.beans.Vendor;
import com.demo.beans.Customer;
import java.util.Scanner;



public class testemployee 
{
	public static void main(String[] args) 
	{
	person p=new person(20,"harshy","946789191");
	System.out.println(p);
//	employee e= new employee(54,"Saud","9734652854","CSE","Assnt Prof");
//	System.out.println(e);
//	SalariedEmp s= new SalariedEmp(67,"kiran","7687425736","ETC","PROF",700000,5000);
//	System.out.println(s);
//	System.out.println(s.calsal());
	Vendor v = new Vendor(100,"shreejai","788978891","finace","accountent",50000,15);
	System.out.println(v);
	System.out.println(v.calsal());
	Customer c = new Customer(104,"Himanshu","8634987346","Regular",15000);
	System.out.println(c);
//	ContractEmp ce = new ContractEmp(121,"Hritik", "6743847176","Pwd","Thekedar",70,6000); 
//	System.out.println(ce.calsal());
	
	Scanner sc = new Scanner(System.in);
	employee e1 = null;
	System.out.println("1. Salaried emp \n 2. ContractEMP");
	int choice = sc.nextInt();
	switch(choice)
	{
	case 1 :
		e1 = new SalariedEmp(67,"kiran","7687425736","ETC","PROF",700000,5000); 
		break;
	case 2 :
		e1 = new ContractEmp(121,"Hritik", "6743847176","Pwd","Thekedar",70,6000);
		break;
	}
	System.out.println(e1.calsal());
    
	}
	

}

