
public class books {

	public static void main(String[] args) {
		book b = new book();
		book.Lesson l = b.new Lesson(25,"him");
		b.method1();
		outer_class oc = new outer_class();
		outer_class.InnerClass ic = oc.new InnerClass();
		ic.method2();
	}

}
