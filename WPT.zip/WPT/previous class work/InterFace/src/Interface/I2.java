package Interface;

public interface I2 
{

	void m21();
	default void m22() 
	{
		System.out.println("in method m22");
	}
	
}
