package Interface;

public interface I6
{
	 void m61();
//	 protected int m3();
}
