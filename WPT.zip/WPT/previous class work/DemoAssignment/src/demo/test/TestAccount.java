package demo.test;
import demo.java.test.*;
import java.util.Scanner;

public class TestAccount {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Saving_Acc s =new Saving_Acc(1,"pratik",1000000,84);
		System.out.println("Checque No :");
	//	int cn = sc.nextInt();
		System.out.println(s.calcintrest());
		
		Current_Acc ca = new Current_Acc(1,"k",150000,95);
		System.out.println("No of transactions done :");
		//int td=sc.nextInt();
		System.out.println(ca.calcintrest());
		
		Demat_Acc da = new Demat_Acc(1,"t2",10000,7000);
		System.out.println("Commission  :");
		//int co=sc.nextInt();
		System.out.println(da.calcintrest());
		

	}

}
