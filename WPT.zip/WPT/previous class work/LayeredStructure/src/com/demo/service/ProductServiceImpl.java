package com.demo.service;
import com.demo.dao.*;
import com.demo.beans.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

public class ProductServiceImpl implements  ProductService {
	private ProductDao pdao;
	
	public ProductServiceImpl() {
		super();
		
		pdao = new ProductdaoImpl();
	}

	@Override
	public boolean addnewProduct() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Id");
		int id = sc.nextInt();
		System.out.println("Enter Name");
		String name = sc.next();
		System.out.println("Enter Quantity");
		int qty = sc.nextInt();
		System.out.println("Enter Price");
		double pr=sc.nextFloat();
		System.out.println("Enter Date of Expiry");
		String expdt = sc.next();
		LocalDate dt = LocalDate.parse(expdt,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		
		Product p = new Product(id,name,qty,pr,dt);
		return pdao.save(p);		
	}

	@Override
	public List<Product> displayall() {
		
		return pdao.findall();
	}

	@Override
	public Product searchById(int pid) {
		// TODO Auto-generated method stub
		return pdao.findById(pid);
	}

	@Override
	public List<Product> searchByPrice(double pr) {
		// TODO Auto-generated method stub
		return pdao.findByPrice(pr);
	}

	@Override
	public List<Product> searchByName(String pnm) {
		// TODO Auto-generated method stub
		return pdao.findByName(pnm);
	}

	@Override
	public List<Product> sortById(int pid) {
		// TODO Auto-generated method stub
		return pdao.sortid();
	}

	@Override
	public int deleteId() {
		// TODO Auto-generated method stub
		return pdao.removeId();
	}

	
	
	
	
		
	
}
