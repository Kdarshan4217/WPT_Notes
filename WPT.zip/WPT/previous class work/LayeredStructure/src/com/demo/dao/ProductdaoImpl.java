package com.demo.dao;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.demo.beans.*;

public class ProductdaoImpl implements ProductDao {
		static List<Product> plist;
		
		static {
			plist = new ArrayList<>();
			plist.add(new Product (1,"Monaco",20,45.00,LocalDate.of(2026, 10, 15)));
			plist.add(new Product (2,"Mari",60,35.00,LocalDate.of(2024, 5, 15)));
			plist.add(new Product (3,"Krackjack",10,25.00,LocalDate.of(2022, 9, 15)));
		}
		
	public boolean save(Product p)
	{
		return plist.add(p);
	}

	@Override
	public List<Product> findall() {
		
		return plist;
	}

	@Override
	public Product findById(int pid) {
		int pos = plist.indexOf(new Product(pid));
		if(pos!=-1) {
			return plist.get(pos);
		}
		return null;
	}

	@Override
	public List<Product> findByPrice(double price) {
		 
		List<Product>lst = plist.stream()
				.filter(ob->ob.getPrice()>price)
				.collect(Collectors.toList());
	     if(lst.isEmpty()) {
	    	 return null;
	     }
	         return lst;
				
	}

	

	@Override
	public List<Product> findByName(String pnm) {
		List<Product>lst=plist.stream()
				.filter(ob->ob.getName().equals(pnm))
				.collect(Collectors.toList());
		if (lst.isEmpty()) {
		
		return null;
	}
		return lst;
	}

	@Override
	public List<Product> sortid() {
		
		return null;
	}
}
		
	


